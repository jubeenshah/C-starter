#include <stdio.h>
#include <kernel.h>
//#include "lab0.h"

static unsigned long *esp; //Stack pointer access as defined in ../sys/stacktrace.c

//#define NOPROCESS NPRC
void printprocstks(int priority){

        /*struct pentry *process;  for access to pentry from proc.h
                                        process->pname  (process name)
                                        process->pbase  (stack base)
                                        process->plimit (stack limit)
                                        process->pprio  (process priority)
                                        process->pstklen(Stack length/size)
                                */
        printf("\nvoid printprocstks(int priority)");

        int processId;



}
